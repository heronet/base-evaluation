/*
 * Copyright (c) 2025 Siratul Islam <siratul.islam@linux.dev>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @file
 * @ingroup biometrics_interface
 * @brief Main header file for biometrics driver API.
 */

#ifndef ZEPHYR_INCLUDE_DRIVERS_BIOMETRICS_H_
#define ZEPHYR_INCLUDE_DRIVERS_BIOMETRICS_H_

/**
 * @brief Interfaces for biometric sensors.
 * @defgroup biometrics_interface Biometrics
 * @since 4.4
 * @version 0.2.0
 * @ingroup io_interfaces
 * @{
 */

#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/types.h>
#include <errno.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Biometric modality flags */
#define BIOMETRIC_MODALITY_FINGERPRINT BIT(0) /**< Fingerprint sensor */
#define BIOMETRIC_MODALITY_IRIS        BIT(1) /**< Iris scanner */
#define BIOMETRIC_MODALITY_FACE        BIT(2) /**< Face recognition */
#define BIOMETRIC_MODALITY_VOICE       BIT(3) /**< Voice recognition */
#define BIOMETRIC_MODALITY_PALM        BIT(4) /**< Palm recognition */

/**
 * @brief Biometric matching modes
 */
enum biometric_match_mode {
	BIOMETRIC_MATCH_VERIFY,   /**< Verify against specific template */
	BIOMETRIC_MATCH_IDENTIFY, /**< Search entire database */
};

/**
 * @brief Biometric storage modes
 */
#define BIOMETRIC_STORAGE_DEVICE BIT(0) /**< Store on sensor device */
#define BIOMETRIC_STORAGE_HOST   BIT(1) /**< Store on host system */

/**
 * @brief Biometric LED states
 */
enum biometric_led_state {
	BIOMETRIC_LED_OFF,    /**< LED off */
	BIOMETRIC_LED_ON,     /**< LED on continuously */
	BIOMETRIC_LED_BLINK,  /**< LED blinking */
	BIOMETRIC_LED_BREATHE /**< LED breathing effect */
};

/**
 * @brief Biometric attribute types
 */
enum biometric_attribute {
	/** Minimum confidence score for match acceptance (sensor-specific range) */
	BIOMETRIC_ATTR_MATCH_THRESHOLD,
	/** Minimum quality score for enrollment acceptance (sensor-specific range) */
	BIOMETRIC_ATTR_ENROLLMENT_QUALITY,
	/** Security level (1-10), higher values reduce false accepts */
	BIOMETRIC_ATTR_SECURITY_LEVEL,
	/** Default operation timeout in milliseconds */
	BIOMETRIC_ATTR_TIMEOUT_MS,
	/** Anti-spoofing detection sensitivity (1-10) */
	BIOMETRIC_ATTR_ANTI_SPOOF_LEVEL,
	/** Last captured image quality score (sensor-specific range), read-only */
	BIOMETRIC_ATTR_IMAGE_QUALITY,
	/** Duplicate enrollment policy (0 = reject duplicates, 1 = allow) */
	BIOMETRIC_ATTR_DUPLICATE_POLICY,
	/**
	 * Number of all common biometric attributes.
	 */
	BIOMETRIC_ATTR_COMMON_COUNT,
	/**
	 * This and higher values are sensor specific.
	 * Refer to the sensor header file.
	 */
	BIOMETRIC_ATTR_PRIV_START = BIOMETRIC_ATTR_COMMON_COUNT,
	/**
	 * Maximum value describing a biometric attribute type.
	 */
	BIOMETRIC_ATTR_MAX = INT16_MAX,
};

/** @brief Request automatic template ID allocation with biometric_enroll_async(). */
#define BIOMETRIC_ID_AUTO 0

/** @brief Optional asynchronous operations. */
#define BIOMETRIC_ASYNC_IDENTIFY BIT(0) /**< Asynchronous identification. */
#define BIOMETRIC_ASYNC_ENROLL   BIT(1) /**< Asynchronous device-managed enrollment. */
#define BIOMETRIC_ASYNC_VERIFY   BIT(2) /**< Asynchronous verification. */

/**
 * @brief Biometric sensor capabilities
 */
struct biometric_capabilities {
	/** Bitmask of supported modalities */
	uint32_t supported_modalities;
	/** Maximum templates device can store */
	uint16_t max_templates;
	/** Template size in bytes, or zero when unavailable. */
	uint16_t template_size;
	/** Bitmask of supported storage modes */
	uint8_t storage_modes;
	/** Staged enrollment sample count, or zero for device-managed enrollment only. */
	uint8_t enrollment_samples_required;
	/** Supported BIOMETRIC_ASYNC_* flags, or zero if none are supported. */
	uint32_t async_operations;
};

/**
 * @brief Result from a biometric match operation
 */
struct biometric_match_result {
	/**
	 * Confidence/match score (sensor-specific scale, higher is better),
	 * or zero if unavailable.
	 */
	int32_t confidence;
	/** Matched template ID (for IDENTIFY mode, or verified ID for VERIFY mode) */
	uint16_t template_id;
	/** Sample quality (0-100), or zero if unavailable. */
	uint8_t image_quality;
	/** Modality that produced this result */
	uint32_t modality;
};

/**
 * @brief Result from an enrollment capture operation
 *
 * Contains progress information and quality feedback for the capture.
 */
struct biometric_capture_result {
	/** Number of samples captured so far */
	uint8_t samples_captured;
	/** Total number of samples required for enrollment */
	uint8_t samples_required;
	/** Quality score of the captured sample (0-100) */
	uint8_t quality;
	/** Assigned template ID */
	uint16_t template_id;
};

/** @brief Asynchronous biometric event types. */
enum biometric_event_type {
	BIOMETRIC_EVENT_MATCH,           /**< Matching succeeded. */
	BIOMETRIC_EVENT_NO_MATCH,        /**< Matching attempt timed out or rejected the sample. */
	BIOMETRIC_EVENT_ENROLL_COMPLETE, /**< Enrollment succeeded and the template is stored. */
	BIOMETRIC_EVENT_ERROR,           /**< An operation or its cleanup failed. */
	BIOMETRIC_EVENT_STOPPED,         /**< Final event of an asynchronous operation. */
};

/** @brief Result of device-managed enrollment. */
struct biometric_enrollment_result {
	uint16_t template_id; /**< Actual stored template ID. */
	uint32_t modality;    /**< Single BIOMETRIC_MODALITY_* flag for the enrolled modality. */
};

/**
 * @brief An asynchronous biometric event.
 *
 * Every accepted asynchronous request ends with exactly one STOPPED event.
 * Operation or cleanup failures report ERROR before STOPPED.
 */
struct biometric_event {
	enum biometric_event_type type; /**< Event discriminator. */
	/** Operation or attempt status: zero on success, negative errno otherwise. */
	int status;
	/** Event-specific result, selected by type. */
	union {
		struct biometric_match_result match;           /**< Valid for MATCH. */
		struct biometric_enrollment_result enrollment; /**< Valid for ENROLL_COMPLETE. */
	};
};

/**
 * @brief Handle a biometric event in driver thread context.
 *
 * Callbacks run in event order and must return promptly. Do not call biometric
 * control or database APIs for this device from the callback.
 * The device remains busy during the final STOPPED callback.
 *
 * @param dev Biometric device.
 * @param event Event, valid only until the callback returns.
 * @param user_data Application context registered with biometric_callback_set().
 */
typedef void (*biometric_event_callback_t)(const struct device *dev,
					   const struct biometric_event *event, void *user_data);

/**
 * @def_driverbackendgroup{Biometrics,biometrics_interface}
 * @{
 */

/**
 * @brief Callback API to get sensor capabilities.
 * See biometric_get_capabilities() for argument description
 */
typedef int (*biometric_api_get_capabilities)(const struct device *dev,
					      struct biometric_capabilities *caps);

/**
 * @brief Callback API to set a sensor attribute.
 * See biometric_attr_set() for argument description.
 */
typedef int (*biometric_api_attr_set)(const struct device *dev, enum biometric_attribute attr,
				      int32_t val);

/**
 * @brief Callback API to get a sensor attribute.
 * See biometric_attr_get() for argument description
 */
typedef int (*biometric_api_attr_get)(const struct device *dev, enum biometric_attribute attr,
				      int32_t *val);

/**
 * @brief Callback API to start enrollment.
 * See biometric_enroll_start() for argument description
 */
typedef int (*biometric_api_enroll_start)(const struct device *dev, uint16_t template_id);

/**
 * @brief Callback API to capture enrollment samples.
 * See biometric_enroll_capture() for argument description
 */
typedef int (*biometric_api_enroll_capture)(const struct device *dev, k_timeout_t timeout,
					    struct biometric_capture_result *result);

/**
 * @brief Callback API to finalize enrollment.
 * See biometric_enroll_finalize() for argument description
 */
typedef int (*biometric_api_enroll_finalize)(const struct device *dev);

/**
 * @brief Callback API to abort enrollment.
 * See biometric_enroll_abort() for argument description
 */
typedef int (*biometric_api_enroll_abort)(const struct device *dev);

/**
 * @brief Callback API to store template.
 * See biometric_template_store() for argument description
 */
typedef int (*biometric_api_template_store)(const struct device *dev, uint16_t id,
					    const uint8_t *data, size_t size);

/**
 * @brief Callback API to read template data.
 * See biometric_template_read() for argument description
 */
typedef int (*biometric_api_template_read)(const struct device *dev, uint16_t id, uint8_t *data,
					   size_t size);

/**
 * @brief Callback API to delete template.
 * See biometric_template_delete() for argument description
 */
typedef int (*biometric_api_template_delete)(const struct device *dev, uint16_t id);

/**
 * @brief Callback API to delete all templates.
 * See biometric_template_delete_all() for argument description
 */
typedef int (*biometric_api_template_delete_all)(const struct device *dev);

/**
 * @brief Callback API to list template IDs.
 * See biometric_template_list() for argument description
 */
typedef int (*biometric_api_template_list)(const struct device *dev, uint16_t *ids,
					   size_t max_count, size_t *actual_count);

/**
 * @brief Callback API to start matching operation.
 * See biometric_match() for argument description
 */
typedef int (*biometric_api_match)(const struct device *dev, enum biometric_match_mode mode,
				   uint16_t template_id, k_timeout_t timeout,
				   struct biometric_match_result *result);

/**
 * @brief Callback API to control LED state.
 * See biometric_led_control() for argument description
 */
typedef int (*biometric_api_led_control)(const struct device *dev, enum biometric_led_state state);

/**
 * @brief Callback API to register an event callback.
 * See biometric_callback_set() for argument description
 */
typedef int (*biometric_api_callback_set)(const struct device *dev,
					  biometric_event_callback_t callback, void *user_data);

/**
 * @brief Callback API to perform asynchronous matching.
 * See biometric_match_async() for argument description
 */
typedef int (*biometric_api_match_async)(const struct device *dev, enum biometric_match_mode mode,
					 uint16_t template_id, bool continuous,
					 k_timeout_t timeout);

/**
 * @brief Callback API to start asynchronous enrollment.
 * See biometric_enroll_async() for argument description
 */
typedef int (*biometric_api_enroll_async)(const struct device *dev, uint16_t template_id,
					  k_timeout_t timeout);

/**
 * @brief Callback API to stop an asynchronous operation.
 * See biometric_async_stop() for argument description
 */
typedef int (*biometric_api_async_stop)(const struct device *dev);

/**
 * @driver_ops{Biometrics}
 */
__subsystem struct biometric_driver_api {
	/**
	 * @driver_ops_mandatory @copybrief biometric_get_capabilities
	 */
	biometric_api_get_capabilities get_capabilities;
	/**
	 * @driver_ops_optional @copybrief biometric_attr_set
	 */
	biometric_api_attr_set attr_set;
	/**
	 * @driver_ops_optional @copybrief biometric_attr_get
	 */
	biometric_api_attr_get attr_get;
	/**
	 * @driver_ops_optional @copybrief biometric_enroll_start
	 */
	biometric_api_enroll_start enroll_start;
	/**
	 * @driver_ops_optional @copybrief biometric_enroll_capture
	 */
	biometric_api_enroll_capture enroll_capture;
	/**
	 * @driver_ops_optional @copybrief biometric_enroll_finalize
	 */
	biometric_api_enroll_finalize enroll_finalize;
	/**
	 * @driver_ops_optional @copybrief biometric_enroll_abort
	 */
	biometric_api_enroll_abort enroll_abort;
	/**
	 * @driver_ops_optional @copybrief biometric_template_store
	 */
	biometric_api_template_store template_store;
	/**
	 * @driver_ops_optional @copybrief biometric_template_read
	 */
	biometric_api_template_read template_read;
	/**
	 * @driver_ops_mandatory @copybrief biometric_template_delete
	 */
	biometric_api_template_delete template_delete;
	/**
	 * @driver_ops_optional @copybrief biometric_template_delete_all
	 */
	biometric_api_template_delete_all template_delete_all;
	/**
	 * @driver_ops_optional @copybrief biometric_template_list
	 */
	biometric_api_template_list template_list;
	/**
	 * @driver_ops_mandatory @copybrief biometric_match
	 */
	biometric_api_match match;
	/**
	 * @driver_ops_optional @copybrief biometric_led_control
	 */
	biometric_api_led_control led_control;
	/**
	 * @driver_ops_optional @copybrief biometric_callback_set
	 */
	biometric_api_callback_set callback_set;
	/**
	 * @driver_ops_optional @copybrief biometric_match_async
	 */
	biometric_api_match_async match_async;
	/**
	 * @driver_ops_optional @copybrief biometric_enroll_async
	 */
	biometric_api_enroll_async enroll_async;
	/**
	 * @driver_ops_optional @copybrief biometric_async_stop
	 */
	biometric_api_async_stop async_stop;
};

/**
 * @}
 */

/**
 * @brief Get biometric sensor capabilities
 *
 * @param dev Pointer to the biometric device
 * @param caps Pointer to capabilities structure to populate
 *
 * @return 0 on success, negative errno value on failure.
 */
__syscall int biometric_get_capabilities(const struct device *dev,
					 struct biometric_capabilities *caps);

static inline int z_impl_biometric_get_capabilities(const struct device *dev,
						    struct biometric_capabilities *caps)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	__ASSERT_NO_MSG(caps != NULL);

	return api->get_capabilities(dev, caps);
}

/**
 * @brief Set a biometric sensor attribute
 *
 * @param dev Pointer to the biometric device
 * @param attr The attribute to set
 * @param val The value to set
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Not supported by device.
 * @retval -EINVAL Invalid attribute or value.
 */
__syscall int biometric_attr_set(const struct device *dev, enum biometric_attribute attr,
				 int32_t val);

static inline int z_impl_biometric_attr_set(const struct device *dev, enum biometric_attribute attr,
					    int32_t val)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->attr_set == NULL) {
		return -ENOSYS;
	}

	return api->attr_set(dev, attr, val);
}

/**
 * @brief Get a biometric sensor attribute
 *
 * @param dev Pointer to the biometric device
 * @param attr The attribute to get
 * @param val Pointer to store the attribute value
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Not supported by device.
 * @retval -EINVAL Invalid attribute.
 */
__syscall int biometric_attr_get(const struct device *dev, enum biometric_attribute attr,
				 int32_t *val);

static inline int z_impl_biometric_attr_get(const struct device *dev, enum biometric_attribute attr,
					    int32_t *val)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	__ASSERT_NO_MSG(val != NULL);

	if (api->attr_get == NULL) {
		return -ENOSYS;
	}

	return api->attr_get(dev, attr, val);
}

/**
 * @brief Start biometric enrollment
 *
 * Begins enrollment for a new template. After calling this, use
 * biometric_enroll_capture() to capture samples, then biometric_enroll_finalize()
 * to complete, or biometric_enroll_abort() to cancel.
 *
 * @param dev Biometric device
 * @param template_id Template ID to assign (1-based: valid range is 1 to max_templates)
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EINVAL Invalid template_id or enrollment in progress.
 * @retval -ENOSPC No space for new template.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_enroll_start(const struct device *dev, uint16_t template_id);

static inline int z_impl_biometric_enroll_start(const struct device *dev, uint16_t template_id)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->enroll_start == NULL) {
		return -ENOSYS;
	}

	return api->enroll_start(dev, template_id);
}

/**
 * @brief Capture enrollment samples
 *
 * Captures a sample for enrollment. This function blocks until a sample is captured
 * or the timeout expires. Call this function multiple times (typically twice) to
 * collect all required samples before finalizing enrollment.
 *
 * @param dev Biometric device
 * @param timeout Timeout for sample capture
 * @param result Optional pointer to capture result structure for progress/quality info.
 *               Pass NULL if not needed.
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EINVAL No enrollment started or already have enough samples.
 * @retval -ETIMEDOUT Timeout waiting for sample.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_enroll_capture(const struct device *dev, k_timeout_t timeout,
				       struct biometric_capture_result *result);

static inline int z_impl_biometric_enroll_capture(const struct device *dev, k_timeout_t timeout,
						  struct biometric_capture_result *result)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->enroll_capture == NULL) {
		return -ENOSYS;
	}

	return api->enroll_capture(dev, timeout, result);
}

/**
 * @brief Finalize enrollment
 *
 * Completes enrollment and stores the template.
 *
 * @param dev Biometric device
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EINVAL Insufficient samples.
 * @retval -ENOSPC No space to store template.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_enroll_finalize(const struct device *dev);

static inline int z_impl_biometric_enroll_finalize(const struct device *dev)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->enroll_finalize == NULL) {
		return -ENOSYS;
	}

	return api->enroll_finalize(dev);
}

/**
 * @brief Abort enrollment
 *
 * Cancels ongoing enrollment and resets enrollment state.
 *
 * @param dev Biometric device
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EALREADY No enrollment in progress.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_enroll_abort(const struct device *dev);

static inline int z_impl_biometric_enroll_abort(const struct device *dev)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->enroll_abort == NULL) {
		return -ENOSYS;
	}

	return api->enroll_abort(dev);
}

/**
 * @brief Store biometric template
 *
 * @details Stores a pre-generated template. Used for host-based storage
 * systems or restoring backed-up templates.
 *
 * @param dev Pointer to the biometric device
 * @param id Template ID
 * @param data Pointer to template data
 * @param size Size of template data in bytes
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EINVAL Invalid template data.
 * @retval -ENOSPC Storage full.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_template_store(const struct device *dev, uint16_t id, const uint8_t *data,
				       size_t size);

static inline int z_impl_biometric_template_store(const struct device *dev, uint16_t id,
						  const uint8_t *data, size_t size)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	__ASSERT_NO_MSG(data != NULL);

	if (api->template_store == NULL) {
		return -ENOSYS;
	}

	return api->template_store(dev, id, data, size);
}

/**
 * @brief Read biometric template
 *
 * @details Retrieves template data. The data buffer must be allocated by
 * caller with sufficient size (check capabilities for template_size).
 *
 * @param dev Pointer to the biometric device
 * @param id Template ID to read
 * @param data Pointer to buffer for template data
 * @param size Size of data buffer
 *
 * @return Number of bytes written on success, negative errno value on failure.
 * @retval -EINVAL Invalid template_id or buffer too small.
 * @retval -ENOENT Template not found.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_template_read(const struct device *dev, uint16_t id, uint8_t *data,
				      size_t size);

static inline int z_impl_biometric_template_read(const struct device *dev, uint16_t id,
						 uint8_t *data, size_t size)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	__ASSERT_NO_MSG(data != NULL);

	if (api->template_read == NULL) {
		return -ENOSYS;
	}

	return api->template_read(dev, id, data, size);
}

/**
 * @brief Delete biometric template
 *
 * @param dev Pointer to the biometric device
 * @param id Template ID to delete
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -EINVAL Invalid template_id.
 * @retval -ENOENT Template not found.
 */
__syscall int biometric_template_delete(const struct device *dev, uint16_t id);

static inline int z_impl_biometric_template_delete(const struct device *dev, uint16_t id)
{
	return DEVICE_API_GET(biometric, dev)->template_delete(dev, id);
}

/**
 * @brief Delete all biometric templates
 *
 * @param dev Pointer to the biometric device
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_template_delete_all(const struct device *dev);

static inline int z_impl_biometric_template_delete_all(const struct device *dev)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->template_delete_all == NULL) {
		return -ENOSYS;
	}

	return api->template_delete_all(dev);
}

/**
 * @brief List stored template IDs
 *
 * @param dev Pointer to the biometric device
 * @param ids Pointer to array to populate with template IDs
 * @param max_count Maximum number of IDs array can hold
 * @param actual_count Pointer to store actual number of IDs returned
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Not supported by device.
 */
__syscall int biometric_template_list(const struct device *dev, uint16_t *ids, size_t max_count,
				      size_t *actual_count);

static inline int z_impl_biometric_template_list(const struct device *dev, uint16_t *ids,
						 size_t max_count, size_t *actual_count)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	__ASSERT_NO_MSG(ids != NULL);
	__ASSERT_NO_MSG(actual_count != NULL);

	if (api->template_list == NULL) {
		return -ENOSYS;
	}

	return api->template_list(dev, ids, max_count, actual_count);
}

/**
 * @brief Perform biometric matching
 *
 * Captures a sample and performs matching. This function blocks until matching
 * completes or timeout expires. For BIOMETRIC_MATCH_VERIFY, verifies against
 * template_id. For BIOMETRIC_MATCH_IDENTIFY, searches all templates.
 *
 * @param dev Biometric device
 * @param mode Verify or identify mode
 * @param template_id Template ID for verify mode (ignored in identify mode)
 * @param timeout Timeout for sample capture and matching
 * @param result Optional pointer to match result structure for detailed info.
 *               Pass NULL if only match/no-match status is needed.
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ETIMEDOUT Timeout waiting for sample.
 * @retval -ENOENT No match found.
 */
__syscall int biometric_match(const struct device *dev, enum biometric_match_mode mode,
			      uint16_t template_id, k_timeout_t timeout,
			      struct biometric_match_result *result);

static inline int z_impl_biometric_match(const struct device *dev, enum biometric_match_mode mode,
					 uint16_t template_id, k_timeout_t timeout,
					 struct biometric_match_result *result)
{
	return DEVICE_API_GET(biometric, dev)->match(dev, mode, template_id, timeout, result);
}

/**
 * @brief Control biometric sensor LED
 *
 * Controls LED state for user feedback during operations.
 *
 * @param dev Biometric device
 * @param state Desired LED state
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Not supported by device.
 * @retval -EINVAL Invalid state.
 */
__syscall int biometric_led_control(const struct device *dev, enum biometric_led_state state);

static inline int z_impl_biometric_led_control(const struct device *dev,
					       enum biometric_led_state state)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->led_control == NULL) {
		return -ENOSYS;
	}

	return api->led_control(dev, state);
}

/**
 * @brief Register an asynchronous event callback while the device is idle.
 *
 * Registration persists across operations and does not start one. Keep user_data
 * valid until the callback is successfully replaced or unregistered while idle.
 *
 * @supervisor
 * @param dev Biometric device.
 * @param callback Event callback, or NULL to unregister while idle.
 * @param user_data Application context, possibly NULL.
 *
 * @return 0 on success, negative errno value on failure.
 * @retval -ENOSYS Callback registration is not implemented.
 * @retval -EBUSY An operation or callback is active.
 * @retval -EWOULDBLOCK Called from ISR or the device's callback thread.
 */
static inline int biometric_callback_set(const struct device *dev,
					 biometric_event_callback_t callback, void *user_data)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->callback_set == NULL) {
		return -ENOSYS;
	}

	return api->callback_set(dev, callback, user_data);
}

/**
 * @brief Perform asynchronous biometric matching.
 *
 * Requires a registered callback. Returns after accepting the request.
 * Detects modality automatically and reports MATCH or NO_MATCH per attempt.
 * Continuous matching runs until stopped or a fatal error occurs.
 * For a single attempt, STOPPED reports zero after normal completion and
 * successful cleanup, including after NO_MATCH.
 *
 * @param dev Biometric device.
 * @param mode Verify against one template or identify against the database.
 * @param template_id Template ID for verification (1 to max_templates); ignored for identification.
 * @param continuous True to repeat attempts, false for a single attempt.
 * @param timeout Positive finite timeout for each attempt; drivers may round up.
 *
 * @return 0 if the request is accepted, negative errno value on failure.
 * @retval -ENOSYS Asynchronous matching is not implemented.
 * @retval -ENOTSUP Matching mode or repetition choice is not supported by the device.
 * @retval -EINVAL Invalid mode, template ID, missing callback, or unsupported timeout.
 * @retval -EBUSY An operation or callback is active.
 * @retval -EWOULDBLOCK Called from ISR or the device's callback thread.
 */
__syscall int biometric_match_async(const struct device *dev, enum biometric_match_mode mode,
				    uint16_t template_id, bool continuous, k_timeout_t timeout);

static inline int z_impl_biometric_match_async(const struct device *dev,
					       enum biometric_match_mode mode, uint16_t template_id,
					       bool continuous, k_timeout_t timeout)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->match_async == NULL) {
		return -ENOSYS;
	}

	return api->match_async(dev, mode, template_id, continuous, timeout);
}

/**
 * @brief Enroll a template asynchronously using device-managed capture and storage.
 *
 * Requires a registered callback and returns after accepting the request.
 * Modality is detected automatically. ENROLL_COMPLETE reports the actual stored
 * template's ID and modality.
 *
 * @param dev Biometric device.
 * @param template_id Requested template ID (1 to max_templates), or BIOMETRIC_ID_AUTO
 *                    for automatic allocation.
 * @param timeout Positive finite enrollment timeout; drivers may round up.
 *
 * @return 0 if the request is accepted, negative errno value on failure.
 * @retval -ENOSYS Asynchronous enrollment is not implemented.
 * @retval -ENOTSUP Requested ID allocation policy is not supported.
 * @retval -EINVAL Invalid template ID, missing callback, or unsupported timeout.
 * @retval -EBUSY An operation or callback is active.
 * @retval -EWOULDBLOCK Called from ISR or the device's callback thread.
 */
__syscall int biometric_enroll_async(const struct device *dev, uint16_t template_id,
				     k_timeout_t timeout);

static inline int z_impl_biometric_enroll_async(const struct device *dev, uint16_t template_id,
						k_timeout_t timeout)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->enroll_async == NULL) {
		return -ENOSYS;
	}

	return api->enroll_async(dev, template_id, timeout);
}

/**
 * @brief Stop an asynchronous operation and wait for callbacks to finish.
 *
 * Stopping enrollment does not delete a template already stored by the device.
 * Cancellation reports STOPPED with status -ECANCELED unless cleanup fails.
 * If the operation finishes before cancellation takes effect, its result is preserved.
 *
 * @param dev Biometric device.
 *
 * @return 0 on successful stop and protocol cleanup, negative errno value on failure.
 * @retval -ENOSYS Stopping is not implemented.
 * @retval -EALREADY No asynchronous operation is active.
 * @retval -EBUSY A conflicting control operation is active.
 * @retval -EWOULDBLOCK Called from ISR or the device's callback thread.
 */
__syscall int biometric_async_stop(const struct device *dev);

static inline int z_impl_biometric_async_stop(const struct device *dev)
{
	const struct biometric_driver_api *api = DEVICE_API_GET(biometric, dev);

	if (api->async_stop == NULL) {
		return -ENOSYS;
	}

	return api->async_stop(dev);
}

#ifdef __cplusplus
}
#endif

/**
 * @}
 */

#include <zephyr/syscalls/biometrics.h>

#endif /* ZEPHYR_INCLUDE_DRIVERS_BIOMETRICS_H_ */
